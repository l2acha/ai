# Production Companion Bot ZIP

Telegram AI companion bot starter with:
- aiogram 3.x
- OpenAI Responses API
- persona switching
- memory persistence
- relationship score
- profile command
- memory viewer
- admin commands
- PostgreSQL + Redis compose

## Quick Start

1. Copy `.env.example` to `.env`
2. Fill `BOT_TOKEN` and `OPENAI_API_KEY`
3. Start infra:
   ```bash
   docker compose up -d
   ```
4. Install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python -m app.bot
   ```

## Commands

- `/start`
- `/menu`
- `/profile`
- `/memory`
- `/stats` (admin)
- `/broadcast your message` (admin)

## Notes

- This build keeps the companion grounded and avoids manipulative/dependent behavior.
- Redis is included for future expansion; current build does not require it at runtime.

import asyncio
import logging

from aiogram import Bot, Dispatcher

from app.config import settings
from app.db.session import init_db
from app.handlers import admin, chat, menu, persona, premium, start, profile

logging.basicConfig(level=logging.INFO)


def build_dispatcher() -> Dispatcher:
    dp = Dispatcher()
    dp.include_router(start.router)
    dp.include_router(menu.router)
    dp.include_router(persona.router)
    dp.include_router(profile.router)
    dp.include_router(admin.router)
    dp.include_router(premium.router)
    dp.include_router(chat.router)
    return dp


async def main() -> None:
    await init_db()
    bot = Bot(token=settings.bot_token)
    dp = build_dispatcher()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())

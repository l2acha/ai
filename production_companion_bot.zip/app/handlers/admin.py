from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.config import settings
from app.db.session import SessionLocal
from app.repositories.message_repo import MessageRepository
from app.repositories.user_repo import UserRepository

router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_id_list


@router.message(Command("stats"))
async def stats_handler(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return

    async with SessionLocal() as session:
        user_repo = UserRepository(session)
        message_repo = MessageRepository(session)
        user_count = await user_repo.count_users()
        message_count = await message_repo.count_messages()

    await message.answer(
        f"📊 Bot Stats\n\nUsers: {user_count}\nMessages: {message_count}"
    )


@router.message(Command("broadcast"))
async def broadcast_handler(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Usage: /broadcast your message")
        return

    text = parts[1]

    async with SessionLocal() as session:
        user_repo = UserRepository(session)
        from sqlalchemy import select
        from app.db.models import User

        result = await session.execute(select(User.telegram_user_id))
        targets = [row[0] for row in result.all()]

    sent = 0
    for tg_id in targets:
        try:
            await message.bot.send_message(tg_id, text)
            sent += 1
        except Exception:
            continue

    await message.answer(f"📣 Broadcast sent to {sent} users")

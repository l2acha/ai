from aiogram import F, Router
from aiogram.types import Message

from app.db.session import SessionLocal
from app.repositories.memory_repo import MemoryRepository
from app.repositories.message_repo import MessageRepository
from app.repositories.user_repo import UserRepository
from app.services.llm_service import LLMService
from app.services.memory_service import MemoryService
from app.services.persona_service import get_persona
from app.services.relationship_service import RelationshipService

router = Router()
llm_service = LLMService()
memory_service = MemoryService()
relationship_service = RelationshipService()


@router.message(F.text)
async def chat_handler(message: Message) -> None:
    user_text = message.text.strip()
    if not user_text or user_text.startswith("/"):
        return

    async with SessionLocal() as session:
        user_repo = UserRepository(session)
        memory_repo = MemoryRepository(session)
        message_repo = MessageRepository(session)

        user = await user_repo.get_or_create(
            telegram_user_id=message.from_user.id,
            username=message.from_user.username,
            display_name=message.from_user.full_name,
        )

        extracted = memory_service.extract_memories(user_text)
        for key, value in extracted.items():
            await memory_repo.upsert_memory(user.id, key, value)

        stored_memories = await memory_repo.get_memories(user.id)
        persona = get_persona(user.selected_persona)
        dynamic_state = memory_service.summarize_user_state(
            stored_memories,
            relationship_score=user.relationship_score,
            persona_name=persona.name,
        )

        recent_rows = await message_repo.get_recent_messages(user.id, limit=10)
        recent_history = [
            {"role": row.role, "content": row.content}
            for row in recent_rows
            if row.role in {"user", "assistant"}
        ]

        await message_repo.add_message(user.id, "user", user_text)

        reply = llm_service.generate_reply(
            user_message=user_text,
            persona_prompt=persona.prompt,
            dynamic_state=dynamic_state,
            recent_history=recent_history,
        )

        await message_repo.add_message(user.id, "assistant", reply)

        delta = relationship_service.calculate_delta(user_text)
        user = await user_repo.add_relationship_score(user, delta)
        level = relationship_service.level_from_score(user.relationship_score)

    await message.answer(f"{reply}\n\n— 💖 {level} | Score: {user.relationship_score}")

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.keyboards.main import back_home_menu, main_menu, persona_menu

router = Router()


@router.callback_query(F.data == "menu:home")
async def menu_home(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text("🏠 Main Menu", reply_markup=main_menu())


@router.callback_query(F.data == "menu:chat")
async def menu_chat(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "💬 ส่งข้อความมาคุยได้เลย ฉันจะตอบใน persona ปัจจุบัน",
            reply_markup=back_home_menu(),
        )


@router.callback_query(F.data == "menu:persona")
async def menu_persona(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "👤 เลือก character ได้เลย",
            reply_markup=persona_menu(),
        )


@router.callback_query(F.data == "menu:memory")
async def menu_memory(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "🧠 ใช้ /memory เพื่อดู memory ที่จำไว้",
            reply_markup=back_home_menu(),
        )


@router.callback_query(F.data == "menu:relationship")
async def menu_relationship(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "💖 ใช้ /profile เพื่อดู score และ level ปัจจุบัน",
            reply_markup=back_home_menu(),
        )


@router.callback_query(F.data == "menu:settings")
async def menu_settings(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "⚙️ Starter production pack นี้ยังไม่มี user preferences แยกละเอียด",
            reply_markup=back_home_menu(),
        )

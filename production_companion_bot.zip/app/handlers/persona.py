from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.db.session import SessionLocal
from app.keyboards.main import back_home_menu
from app.repositories.user_repo import UserRepository
from app.services.persona_service import get_persona

router = Router()


@router.callback_query(F.data.startswith("persona:"))
async def select_persona(callback: CallbackQuery) -> None:
    persona_slug = callback.data.split(":", 1)[1]
    persona = get_persona(persona_slug)

    async with SessionLocal() as session:
        repo = UserRepository(session)
        user = await repo.get_or_create(
            telegram_user_id=callback.from_user.id,
            username=callback.from_user.username,
            display_name=callback.from_user.full_name,
        )
        await repo.update_persona(user, persona.slug)

    await callback.answer(f"Switched to {persona.name}")
    if callback.message:
        await callback.message.edit_text(
            f"👤 Current character: {persona.name}\nStyle: {persona.style}",
            reply_markup=back_home_menu(),
        )

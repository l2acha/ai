from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.config import settings

router = Router()


async def is_joined(bot, user_id: int) -> bool:
    if not settings.required_channel:
        return True
    try:
        member = await bot.get_chat_member(settings.required_channel, user_id)
        return member.status in {"member", "administrator", "creator"}
    except Exception:
        return False


@router.callback_query(F.data == "menu:premium")
async def premium_handler(callback: CallbackQuery) -> None:
    joined = await is_joined(callback.bot, callback.from_user.id)

    if not joined:
        await callback.answer("กรุณาเข้าช่องก่อน", show_alert=True)
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📢 Join Channel",
                        url=f"https://t.me/{settings.required_channel.lstrip('@')}",
                    )
                ],
                [InlineKeyboardButton(text="✅ Check Again", callback_data="menu:premium")],
                [InlineKeyboardButton(text="🏠 Home", callback_data="menu:home")],
            ]
        )
        if callback.message:
            await callback.message.edit_text("Premium ถูกล็อกอยู่", reply_markup=kb)
        return

    await callback.answer()
    if callback.message:
        await callback.message.edit_text(
            "⭐ Premium unlocked\nตรงนี้ต่อยอดเป็น special persona / media / bonus content ได้",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="🏠 Home", callback_data="menu:home")]
                ]
            ),
        )

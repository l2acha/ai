from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.db.session import SessionLocal
from app.repositories.memory_repo import MemoryRepository
from app.repositories.user_repo import UserRepository
from app.services.persona_service import get_persona
from app.services.relationship_service import RelationshipService

router = Router()
relationship_service = RelationshipService()


@router.message(Command("profile"))
async def profile_handler(message: Message) -> None:
    async with SessionLocal() as session:
        user_repo = UserRepository(session)
        memory_repo = MemoryRepository(session)
        user = await user_repo.get_or_create(
            telegram_user_id=message.from_user.id,
            username=message.from_user.username,
            display_name=message.from_user.full_name,
        )
        memories = await memory_repo.get_memories(user.id)

    persona = get_persona(user.selected_persona)
    level = relationship_service.level_from_score(user.relationship_score)
    preferred_name = memories.get("name", message.from_user.full_name or "friend")

    text = (
        f"👤 Profile\n\n"
        f"Name: {preferred_name}\n"
        f"Persona: {persona.name}\n"
        f"Style: {persona.style}\n"
        f"Relationship: {level}\n"
        f"Score: {user.relationship_score}"
    )
    await message.answer(text)


@router.message(Command("memory"))
async def memory_handler(message: Message) -> None:
    async with SessionLocal() as session:
        user_repo = UserRepository(session)
        memory_repo = MemoryRepository(session)
        user = await user_repo.get_or_create(
            telegram_user_id=message.from_user.id,
            username=message.from_user.username,
            display_name=message.from_user.full_name,
        )
        memories = await memory_repo.get_memories(user.id)

    if not memories:
        await message.answer("🧠 ยังไม่มี memory ที่เก็บไว้ ลองบอกชื่อหรือสิ่งที่คุณชอบก่อน")
        return

    lines = [f"- {k}: {v}" for k, v in memories.items()]
    await message.answer("🧠 Stored Memory\n\n" + "\n".join(lines))

from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

from app.keyboards.main import main_menu

router = Router()


@router.message(CommandStart())
async def start_handler(message: Message) -> None:
    await message.answer(
        "หวัดดี ✨\nฉันคือ AI companion ของคุณ\nเลือกเมนูด้านล่างได้เลย",
        reply_markup=main_menu(),
    )


@router.message(Command("menu"))
async def menu_handler(message: Message) -> None:
    await message.answer("🏠 Main Menu", reply_markup=main_menu())

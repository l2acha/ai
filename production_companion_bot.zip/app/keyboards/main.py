from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💬 Chat", callback_data="menu:chat")],
            [InlineKeyboardButton(text="👤 Choose Character", callback_data="menu:persona")],
            [InlineKeyboardButton(text="🧠 My Memory", callback_data="menu:memory")],
            [InlineKeyboardButton(text="💖 Relationship", callback_data="menu:relationship")],
            [InlineKeyboardButton(text="⭐ Premium", callback_data="menu:premium")],
            [InlineKeyboardButton(text="⚙️ Settings", callback_data="menu:settings")],
        ]
    )


def back_home_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🏠 Home", callback_data="menu:home")]]
    )


def persona_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🌙 Luna", callback_data="persona:luna")],
            [InlineKeyboardButton(text="⚡ Nova", callback_data="persona:nova")],
            [InlineKeyboardButton(text="🏠 Home", callback_data="menu:home")],
        ]
    )

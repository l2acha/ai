from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Memory


class MemoryRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def upsert_memory(self, user_id: int, key: str, value: str) -> None:
        stmt = select(Memory).where(Memory.user_id == user_id, Memory.key == key)
        result = await self.session.execute(stmt)
        row = result.scalar_one_or_none()

        if row:
            row.value = value
        else:
            row = Memory(user_id=user_id, key=key, value=value)
            self.session.add(row)

        await self.session.commit()

    async def get_memories(self, user_id: int) -> dict[str, str]:
        stmt = select(Memory).where(Memory.user_id == user_id)
        result = await self.session.execute(stmt)
        rows = result.scalars().all()
        return {row.key: row.value for row in rows}

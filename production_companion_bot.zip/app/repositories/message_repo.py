from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import MessageLog


class MessageRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def add_message(self, user_id: int, role: str, content: str) -> None:
        row = MessageLog(user_id=user_id, role=role, content=content)
        self.session.add(row)
        await self.session.commit()

    async def get_recent_messages(self, user_id: int, limit: int = 12) -> list[MessageLog]:
        stmt = (
            select(MessageLog)
            .where(MessageLog.user_id == user_id)
            .order_by(desc(MessageLog.created_at))
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(reversed(result.scalars().all()))

    async def count_messages(self) -> int:
        result = await self.session.execute(select(func.count()).select_from(MessageLog))
        return int(result.scalar_one())

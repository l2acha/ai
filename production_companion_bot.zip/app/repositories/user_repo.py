from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import User


class UserRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_or_create(self, telegram_user_id: int, username: str | None, display_name: str | None) -> User:
        stmt = select(User).where(User.telegram_user_id == telegram_user_id)
        result = await self.session.execute(stmt)
        user = result.scalar_one_or_none()

        if user:
            user.username = username
            user.display_name = display_name
            user.last_seen_at = datetime.utcnow()
            await self.session.commit()
            await self.session.refresh(user)
            return user

        user = User(
            telegram_user_id=telegram_user_id,
            username=username,
            display_name=display_name,
            relationship_score=0,
            selected_persona="luna",
        )
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def update_persona(self, user: User, persona_slug: str) -> User:
        user.selected_persona = persona_slug
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def add_relationship_score(self, user: User, delta: int) -> User:
        user.relationship_score += delta
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def count_users(self) -> int:
        result = await self.session.execute(select(func.count()).select_from(User))
        return int(result.scalar_one())

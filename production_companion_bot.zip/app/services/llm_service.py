from openai import OpenAI

from app.config import settings


class LLMService:
    def __init__(self) -> None:
        self.client = OpenAI(api_key=settings.openai_api_key)

    def build_instructions(self, persona_prompt: str, dynamic_state: str) -> str:
        return f"""
You are a Telegram AI companion.
Be emotionally warm, concise, and consistent.
Do not claim to be a real human.
Do not encourage emotional dependency or exclusivity.
Avoid manipulative, coercive, sexual, or unsafe behavior.
Prefer short paragraphs.

Persona:
{persona_prompt}

Dynamic state:
{dynamic_state}
        """.strip()

    def generate_reply(self, user_message: str, persona_prompt: str, dynamic_state: str, recent_history: list[dict]) -> str:
        instructions = self.build_instructions(persona_prompt, dynamic_state)

        input_items = []
        for item in recent_history:
            input_items.append(
                {
                    "role": item["role"],
                    "content": [{"type": "input_text", "text": item["content"]}],
                }
            )

        input_items.append(
            {
                "role": "user",
                "content": [{"type": "input_text", "text": user_message}],
            }
        )

        response = self.client.responses.create(
            model=settings.openai_model,
            instructions=instructions,
            input=input_items,
        )
        return response.output_text

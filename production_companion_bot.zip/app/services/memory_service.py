class MemoryService:
    def extract_memories(self, text: str) -> dict[str, str]:
        memories: dict[str, str] = {}
        lowered = text.lower()

        if "my name is " in lowered:
            try:
                original_index = lowered.index("my name is ")
                segment = text[original_index + len("my name is "):].strip()
                memories["name"] = segment.split()[0].strip(".,!?").title()
            except Exception:
                pass

        if "i like " in lowered:
            try:
                original_index = lowered.index("i like ")
                segment = text[original_index + len("i like "):].strip()
                memories["likes"] = segment[:120]
            except Exception:
                pass

        if "favorite game" in lowered and "is" in lowered:
            try:
                memories["favorite_game"] = text.split("is", 1)[1].strip()[:120]
            except Exception:
                pass

        return memories

    def summarize_user_state(self, memories: dict[str, str], relationship_score: int, persona_name: str) -> str:
        name = memories.get("name", "friend")
        likes = memories.get("likes", "unknown")
        favorite_game = memories.get("favorite_game", "unknown")
        return (
            f"User preferred name: {name}\n"
            f"User likes: {likes}\n"
            f"Favorite game: {favorite_game}\n"
            f"Relationship score: {relationship_score}\n"
            f"Current persona: {persona_name}\n"
            "Current mood: cheerful"
        )

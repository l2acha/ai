class RelationshipService:
    def calculate_delta(self, user_text: str) -> int:
        text = user_text.strip()
        if not text:
            return 0

        delta = 1
        if len(text) > 80:
            delta += 1
        if any(word in text.lower() for word in ["thank", "miss", "love", "like"]):
            delta += 1
        return delta

    def level_from_score(self, score: int) -> str:
        if score >= 50:
            return "Partner Vibes"
        if score >= 25:
            return "Close"
        if score >= 10:
            return "Warm"
        return "New Spark"
